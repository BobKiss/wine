<?php

interface WPML_ACF_Convertable {
	public function convert(WPML_ACF_Field $WPML_ACF_Field);
}
