<?php

class WPML_ACF_Page_Link_Field extends WPML_ACF_Field {

	public function field_type() {
		return "page_link";
	}

}
