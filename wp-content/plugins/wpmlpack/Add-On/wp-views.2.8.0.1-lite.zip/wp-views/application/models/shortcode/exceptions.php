<?php

/**
 * Class WPV_Exception_Invalid_Shortcode_Attr_Item
 *
 * @since 2.5.0
 */
class WPV_Exception_Invalid_Shortcode_Attr_Item extends Exception {}